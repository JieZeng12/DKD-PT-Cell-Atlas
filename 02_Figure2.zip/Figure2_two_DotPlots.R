library(Seurat)
library(ggplot2)
library(scales)

# ============================================================
# 1. 输出目录
# ============================================================
out_dir <- "I:/DKD/DKD-SingleCell/Result/Figure2"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

# ============================================================
# 2. 检查元数据并筛选细胞
# ============================================================
required_cols <- c("cell_type_final", "condition")
missing_cols <- setdiff(required_cols, colnames(da@meta.data))

if (length(missing_cols) > 0) {
  stop("元数据缺少列：", paste(missing_cols, collapse = ", "))
}

cell_types <- c("PT", "PT_VCAM1", "TAL", "Monocytes", "FIB")
conditions <- c("Control", "Diabetes")

md <- da@meta.data
keep <- md$cell_type_final %in% cell_types &
  md$condition %in% conditions

if (!any(keep)) {
  stop("筛选后没有细胞，请检查 cell_type_final 和 condition。")
}

da_plot <- subset(da, cells = rownames(md)[keep])
da_plot$Plot_group <- paste(
  da_plot$cell_type_final,
  da_plot$condition,
  sep = "_"
)

# levels 从下往上排列：PT_Diabetes 在最下，FIB_Control 在最上。
group_order <- as.vector(rbind(
  paste0(cell_types, "_Diabetes"),
  paste0(cell_types, "_Control")
))

da_plot$Plot_group <- factor(da_plot$Plot_group, levels = group_order)

cat("各组细胞数：\n")
print(table(da_plot$Plot_group, useNA = "ifany"))

# ============================================================
# 3. 基因列表
# ============================================================
genes_top <- c("HSPA1A", "UMOD", "DEFB1", "LRP2", "CPT1A", "ABCB1")
genes_bottom <- c("LRP2", "HSPA5", "VCAM1", "SPP1", "COL1A1", "MMP1")
all_genes <- unique(c(genes_top, genes_bottom))

DefaultAssay(da_plot) <- "RNA"
missing_genes <- setdiff(all_genes, rownames(da_plot[["RNA"]]))

if (length(missing_genes) > 0) {
  stop("RNA assay 中缺少以下基因：", paste(missing_genes, collapse = ", "))
}

# ============================================================
# 4. 一次性计算全部基因的 DotPlot 数值
# ============================================================
dot_base <- DotPlot(
  object = da_plot,
  features = all_genes,
  assay = "RNA",
  group.by = "Plot_group",
  scale = TRUE,
  col.min = -2.5,
  col.max = 2.5
)

dot_data <- dot_base$data
dot_data$id <- factor(as.character(dot_data$id), levels = group_order)

write.csv(
  dot_data,
  file = file.path(out_dir, "Figure2_DotPlot_all_gene_values.csv"),
  row.names = FALSE
)

# ============================================================
# 5. 统一绘图函数
# ============================================================
make_dotplot <- function(genes, plot_title) {
  df <- dot_data[
    as.character(dot_data$features.plot) %in% genes,
    ,
    drop = FALSE
  ]

  df$features.plot <- factor(
    as.character(df$features.plot),
    levels = genes
  )

  ggplot(df, aes(x = features.plot, y = id)) +
    geom_point(aes(size = pct.exp, colour = avg.exp.scaled)) +
    scale_colour_gradient2(
      low = "#233B9B",
      mid = "#F7F7F7",
      high = "#E53935",
      midpoint = 0,
      limits = c(-2.5, 2.5),
      oob = scales::squish,
      breaks = c(-2, -1, 0, 1, 2),
      name = "Average expression\n(scaled)"
    ) +
    scale_size_area(
      max_size = 8,
      limits = c(0, 100),
      breaks = c(0, 20, 40, 60, 80, 100),
      name = "Percent expressed"
    ) +
    scale_y_discrete(limits = group_order, drop = FALSE) +
    labs(title = plot_title, x = NULL, y = NULL) +
    theme_bw(base_size = 12) +
    theme(
      plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
      axis.text.x = element_text(
        angle = 45, hjust = 1, vjust = 1, colour = "black", size = 11
      ),
      axis.text.y = element_text(colour = "black", size = 10),
      panel.grid.major = element_line(colour = "grey90", linewidth = 0.3),
      panel.grid.minor = element_blank(),
      legend.position = "right"
    )
}

# ============================================================
# 6. 绘制两张图
# ============================================================
p_top <- make_dotplot(genes_top, "Cell-type markers")
p_bottom <- make_dotplot(genes_bottom, "VCAM1+ PT-associated markers")

print(p_top)
print(p_bottom)

# ============================================================
# 7. 保存 PDF 和 PNG
# ============================================================
ggsave(
  filename = file.path(out_dir, "Figure2_DotPlot_cell_type_markers.pdf"),
  plot = p_top, width = 10, height = 6, units = "in"
)
ggsave(
  filename = file.path(out_dir, "Figure2_DotPlot_cell_type_markers.png"),
  plot = p_top, width = 10, height = 6, units = "in", dpi = 300
)
ggsave(
  filename = file.path(out_dir, "Figure2_DotPlot_VCAM1_PT_markers.pdf"),
  plot = p_bottom, width = 10, height = 6, units = "in"
)
ggsave(
  filename = file.path(out_dir, "Figure2_DotPlot_VCAM1_PT_markers.png"),
  plot = p_bottom, width = 10, height = 6, units = "in", dpi = 300
)

cat("\n全部结果已保存至：\n", out_dir, "\n")
