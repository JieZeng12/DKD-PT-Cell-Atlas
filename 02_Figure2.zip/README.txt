Module: Figure 2 cell-type dot plots.
Input: load Seurat object `da` with `cell_type_final` and `condition` metadata.
Edit the output path in the R script before running.
