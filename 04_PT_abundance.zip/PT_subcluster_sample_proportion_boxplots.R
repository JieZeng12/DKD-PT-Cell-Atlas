# Donor/sample-level boxplots of PT-subcluster proportions by condition.
# Run after loading the PT-only Seurat object `vam`.

suppressPackageStartupMessages({
  library(Seurat)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(scales)
  library(readr)
})

if (!exists("vam")) stop("Please load the PT-only Seurat object as `vam` first.")
md <- vam[[]]
required_cols <- c("orig.ident", "PT_subcluster")
missing_cols <- setdiff(required_cols, colnames(md))
if (length(missing_cols) > 0) {
  stop("Missing metadata column(s): ", paste(missing_cols, collapse = ", "))
}

out_dir <- "I:/DKD/DKD-SingleCell/Result/Figure6"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

# Determine the condition from metadata when available; otherwise map the
# sample identifiers shown in the current dataset.
sample_info <- md %>%
  transmute(sample_id = as.character(orig.ident),
            condition_raw = if ("condition" %in% colnames(md)) as.character(md$condition) else NA_character_) %>%
  distinct()

infer_group <- function(sample_id, condition_raw) {
  z <- tolower(trimws(condition_raw))
  if (!is.na(z) && z %in% c("control", "normal", "healthy")) return("Control")
  if (!is.na(z) && z %in% c("diabetes", "dkd", "disease")) return("Diabetes/DKD")
  s <- tolower(sample_id)
  if (grepl("control|^nm[0-9]", s)) return("Control")
  if (grepl("diabetes|^dkd[0-9]", s)) return("Diabetes/DKD")
  NA_character_
}

sample_info <- sample_info %>%
  rowwise() %>%
  mutate(Group = infer_group(sample_id, condition_raw),
         Dataset = case_when(
           grepl("^gsm", tolower(sample_id)) ~ "GSE131882",
           grepl("^(nm|dkd)", tolower(sample_id)) ~ "GSE209781",
           TRUE ~ "Other"
         )) %>%
  ungroup()

if (anyNA(sample_info$Group)) {
  stop("Could not determine group for sample(s): ",
       paste(sample_info$sample_id[is.na(sample_info$Group)], collapse = ", "),
       ". Please check/add sample-to-condition mapping.")
}

cell_counts <- md %>%
  transmute(sample_id = as.character(orig.ident),
            PT_subcluster = as.character(PT_subcluster)) %>%
  count(sample_id, PT_subcluster, name = "n_cells")

sample_totals <- md %>%
  transmute(sample_id = as.character(orig.ident)) %>%
  count(sample_id, name = "total_PT_cells")

subcluster_levels <- sort(unique(as.character(md$PT_subcluster)))

plot_dat <- sample_totals %>%
  select(sample_id) %>%
  crossing(PT_subcluster = subcluster_levels) %>%
  left_join(cell_counts, by = c("sample_id", "PT_subcluster")) %>%
  mutate(n_cells = replace_na(n_cells, 0L)) %>%
  left_join(sample_totals, by = "sample_id") %>%
  left_join(sample_info %>% select(sample_id, Group, Dataset), by = "sample_id") %>%
  mutate(Proportion = n_cells / total_PT_cells,
         Group = factor(Group, levels = c("Control", "Diabetes/DKD")),
         PT_subcluster = factor(PT_subcluster, levels = subcluster_levels),
         Dataset = factor(Dataset, levels = c("GSE131882", "GSE209781", "Other")))

group_cols <- c("Control" = "#E6785A", "Diabetes/DKD" = "#48A6B4")
dataset_shapes <- c("GSE131882" = 16, "GSE209781" = 17, "Other" = 15)

# Sample-level group comparisons. Each sample/donor contributes one value per
# PT subcluster; BH correction is applied across all subclusters.
stat_table <- plot_dat %>%
  group_by(PT_subcluster) %>%
  summarise(
    n_control = sum(Group == "Control" & !is.na(Proportion)),
    n_disease = sum(Group == "Diabetes/DKD" & !is.na(Proportion)),
    median_control = median(Proportion[Group == "Control"], na.rm = TRUE),
    median_disease = median(Proportion[Group == "Diabetes/DKD"], na.rm = TRUE),
    median_difference = median_disease - median_control,
    p_value = tryCatch(
      wilcox.test(Proportion ~ Group, data = cur_data(), exact = FALSE)$p.value,
      error = function(e) NA_real_
    ),
    .groups = "drop"
  ) %>%
  mutate(p_adjust_BH = p.adjust(p_value, method = "BH"),
         p_label = paste0("BH-FDR = ", format.pval(p_adjust_BH, digits = 2, eps = 0.001)))

stat_y <- plot_dat %>%
  group_by(PT_subcluster) %>%
  summarise(y = max(Proportion, na.rm = TRUE) * 1.15 + 0.005, .groups = "drop")
stat_table <- left_join(stat_table, stat_y, by = "PT_subcluster")

p <- ggplot(plot_dat, aes(x = Group, y = Proportion, fill = Group, color = Group)) +
  geom_boxplot(width = 0.58, outlier.shape = NA, alpha = 0.25,
               linewidth = 0.75) +
  geom_point(aes(shape = Dataset),
             position = position_jitter(width = 0.10, height = 0, seed = 2026),
             size = 2.5, alpha = 0.85) +
  geom_text(data = stat_table,
            aes(x = 1.5, y = y, label = p_label),
            inherit.aes = FALSE, size = 3.1, color = "#343A40") +
  facet_wrap(~PT_subcluster, scales = "free_y", ncol = 4) +
  scale_fill_manual(values = group_cols) +
  scale_color_manual(values = group_cols) +
  scale_shape_manual(values = dataset_shapes, drop = FALSE) +
  scale_y_continuous(labels = percent_format(accuracy = 1),
                     expand = expansion(mult = c(0.04, 0.12))) +
  labs(title = "PT subcluster proportions by disease group",
       subtitle = "Each point represents one sample; proportions are calculated among PT cells within each sample",
       x = NULL, y = "Proportion of PT cells",
       fill = NULL, color = NULL, shape = "Dataset") +
  theme_classic(base_size = 15) +
  theme(plot.title = element_text(face = "bold", size = 20, hjust = 0.5),
        plot.subtitle = element_text(size = 12, color = "grey35", hjust = 0.5),
        strip.background = element_rect(fill = "#EEF2F4", color = NA),
        strip.text = element_text(face = "bold", size = 12),
        axis.text = element_text(color = "black", size = 12),
        axis.title.y = element_text(face = "bold", margin = margin(r = 10)),
        legend.position = "top",
        panel.spacing = grid::unit(1.1, "lines"),
        panel.grid.major.y = element_line(color = "#E9ECEF", linewidth = 0.4),
        panel.grid.minor = element_blank())

print(p)

ggsave(file.path(out_dir, "PT_subcluster_sample_proportions.pdf"), p,
       width = 14, height = 9, device = grDevices::cairo_pdf)
ggsave(file.path(out_dir, "PT_subcluster_sample_proportions.png"), p,
       width = 14, height = 9, dpi = 320, bg = "white")

write_csv(plot_dat,
          file.path(out_dir, "PT_subcluster_sample_proportions.csv"))
write_csv(stat_table,
          file.path(out_dir, "PT_subcluster_sample_proportion_statistics.csv"))

message("Saved plot and sample-level data to: ", normalizePath(out_dir))
