Module: donor-level PT-subcluster proportions and group comparisons.
Input: load PT-only Seurat object `vam` with `orig.ident` and `PT_subcluster` metadata.
Check the group labels and output path before running.
