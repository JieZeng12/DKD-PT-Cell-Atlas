suppressPackageStartupMessages({
  library(dplyr)
  library(openxlsx)
})

if (!exists("ma")) stop("Load FindAllMarkers() output as `ma` first.")

marker_data <- as.data.frame(ma, check.names = FALSE)
if ("gene" %in% names(marker_data)) {
  gene_col <- "gene"
} else {
  marker_data$gene <- rownames(marker_data)
  gene_col <- "gene"
}

fc_col <- intersect(c("avg_log2FC", "avg_logFC"), names(marker_data))[1]
if (is.na(fc_col)) stop("No avg_log2FC or avg_logFC column found.")
if (!all(c("cluster", "p_val_adj") %in% names(marker_data))) {
  stop("Required columns: cluster and p_val_adj.")
}
marker_data$cluster <- as.character(marker_data$cluster)

naming_genes <- c(
  "GPX3+ PT" = "GPX3",
  "CFH+ PT" = "CFH",
  "MMP7+ PT" = "MMP7",
  "UMOD+ PT-like" = "UMOD",
  "CCN2+ PT" = "CCN2",
  "ACSM2A+ PT" = "ACSM2A",
  "TACSTD2+ PT" = "TACSTD2"
)

top_markers <- marker_data %>%
  filter(!is.na(.data[[gene_col]]), !is.na(p_val_adj), p_val_adj < 0.05,
         .data[[fc_col]] > 0.25) %>%
  group_by(cluster) %>%
  arrange(p_val_adj, desc(.data[[fc_col]]), .by_group = TRUE) %>%
  slice_head(n = 5) %>%
  summarise(`Top 5 marker genes` = paste(.data[[gene_col]], collapse = ", "),
            .groups = "drop")

marker_list <- tibble::tibble(
  `PT subcluster` = names(naming_genes),
  `Defining gene` = unname(naming_genes)
) %>%
  left_join(top_markers, by = c("PT subcluster" = "cluster")) %>%
  select(`PT subcluster`, `Top 5 marker genes`, `Defining gene`)

write.xlsx(marker_list, "PT_subcluster_marker_list.xlsx", overwrite = TRUE)
write.csv(marker_list, "PT_subcluster_marker_list.csv", row.names = FALSE)
