Module: export the top five marker genes per PT subcluster.
Input: load `FindAllMarkers()` output as `ma`.
Requires `dplyr` and `openxlsx`. Outputs XLSX and CSV files to the working directory.
