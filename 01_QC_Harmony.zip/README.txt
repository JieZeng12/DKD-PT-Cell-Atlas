Module: sample QC, Harmony diagnostics, donor contributions, and abundance plots.
Inputs: load `da` first; optionally load `da_pre` and `vam`.
Edit the settings and output path at the top of the R script before running.
