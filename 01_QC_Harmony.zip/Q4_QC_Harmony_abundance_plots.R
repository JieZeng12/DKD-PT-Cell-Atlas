# ============================================================
# Reviewer Q4: sample-level QC, Harmony diagnostics,
# donor contributions, and donor-level abundance plots
# ============================================================
# Expected Seurat objects in the R environment:
#   da      : post-QC integrated object containing all major cell types
#   vam     : PT-only object with PT subclusters (optional but recommended)
#   da_pre  : pre-filter object (optional; needed for pre/post QC comparison)
#
# Check and edit the column names and group labels in Section 0 before running.

suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(tibble)
  library(patchwork)
  library(scales)
})

# ---------------------------
# 0. User settings
# ---------------------------
obj_post <- da
obj_pre <- if (exists("da_pre", envir = .GlobalEnv)) get("da_pre", envir = .GlobalEnv) else NULL
pt_obj <- if (exists("vam", envir = .GlobalEnv)) vam else NULL

sample_col  <- "orig.ident"       # donor/sample identifier
dataset_col <- "dataset"          # dataset accession or dataset label
group_col   <- "condition"        # disease/control column
major_col   <- "cell_type_final"  # major cell-type annotation in da
pt_subtype_col <- "PT_subcluster" # if absent, current Idents(vam) are used

control_label <- "Control"
disease_labels <- c("Diabetes", "DKD", "Disease")
output_dir <- file.path(getwd(), "Q4_QC_Harmony_abundance")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

# ---------------------------
# 1. Utility functions
# ---------------------------
check_columns <- function(object, columns, object_name = "Seurat object") {
  missing <- setdiff(columns, colnames(object[[]]))
  if (length(missing)) {
    stop(object_name, " is missing metadata column(s): ", paste(missing, collapse = ", "),
         "\nAvailable columns: ", paste(colnames(object[[]]), collapse = ", "))
  }
}

get_md <- function(object, object_name = "object") {
  md <- object[[]] %>% rownames_to_column("cell_id")
  check_columns(object, c(sample_col, dataset_col, group_col), object_name)
  md %>%
    mutate(
      sample_id = as.character(.data[[sample_col]]),
      dataset_id = as.character(.data[[dataset_col]]),
      condition = as.character(.data[[group_col]])
    )
}

get_qc_md <- function(object, stage) {
  md <- get_md(object, paste0(stage, " object"))
  if (!"nFeature_RNA" %in% names(md)) {
    stop("nFeature_RNA not found in ", stage, " object.")
  }
  if (!"nCount_RNA" %in% names(md)) {
    stop("nCount_RNA not found in ", stage, " object.")
  }
  if (!"percent.mt" %in% names(md)) {
    object$percent.mt <- PercentageFeatureSet(object, pattern = "^MT-")
    md$percent.mt <- object$percent.mt[md$cell_id]
  }
  md$QC_stage <- stage
  md
}

save_plot <- function(plot, filename, width, height) {
  ggsave(file.path(output_dir, filename), plot, width = width, height = height,
         dpi = 300, bg = "white")
}

# ---------------------------
# 2. Sample-level QC summaries and plots
# ---------------------------
qc_post <- get_qc_md(obj_post, "Post-filtering")
qc_all <- qc_post

if (!is.null(obj_pre)) {
  qc_pre <- get_qc_md(obj_pre, "Pre-filtering")
  qc_all <- bind_rows(qc_pre, qc_post)
} else {
  message("da_pre was not found: pre-filtering plots/counts will be omitted. ",
          "Assign the unfiltered Seurat object to da_pre to include them.")
}

qc_summary <- qc_all %>%
  group_by(QC_stage, dataset_id, sample_id, condition) %>%
  summarise(
    n_cells_or_nuclei = n(),
    median_nFeature = median(nFeature_RNA, na.rm = TRUE),
    median_nCount = median(nCount_RNA, na.rm = TRUE),
    median_percent_mt = median(percent.mt, na.rm = TRUE),
    median_percent_ribo = if ("percent.ribo" %in% names(cur_data())) {
      median(percent.ribo, na.rm = TRUE)
    } else NA_real_,
    .groups = "drop"
  )

write.csv(qc_summary, file.path(output_dir, "01_sample_level_QC_summary.csv"), row.names = FALSE)

qc_long <- qc_all %>%
  select(QC_stage, dataset_id, sample_id, condition,
         nFeature_RNA, nCount_RNA, percent.mt) %>%
  pivot_longer(cols = c(nFeature_RNA, nCount_RNA, percent.mt),
               names_to = "metric", values_to = "value")

p_qc <- ggplot(qc_long, aes(x = sample_id, y = value, fill = condition)) +
  geom_violin(scale = "width", trim = TRUE, linewidth = 0.15) +
  facet_grid(QC_stage + dataset_id ~ metric, scales = "free_y", space = "free_x") +
  labs(x = NULL, y = "Per-cell value", fill = "Group",
       title = "Sample-level QC metrics") +
  theme_classic(base_size = 10) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        strip.text = element_text(size = 8), legend.position = "top")
save_plot(p_qc, "02_QC_metrics_by_sample.pdf", width = 14, height = 8)

p_qc_n <- ggplot(qc_summary,
                 aes(x = sample_id, y = n_cells_or_nuclei, fill = condition)) +
  geom_col(width = 0.8) +
  facet_grid(QC_stage ~ dataset_id, scales = "free_x", space = "free_x") +
  labs(x = NULL, y = "Cells / nuclei retained", fill = "Group",
       title = "Cell or nucleus counts per sample") +
  theme_classic(base_size = 10) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = "top")
save_plot(p_qc_n, "03_cell_counts_by_sample.pdf", width = 12, height = 5)

# ---------------------------
# 3. Harmony diagnostics before/after integration
# ---------------------------
reductions_present <- Reductions(obj_post)
if (all(c("pca", "harmony") %in% reductions_present)) {
  obj_diag <- obj_post
  n_dims <- min(30,
                ncol(Embeddings(obj_diag, "pca")),
                ncol(Embeddings(obj_diag, "harmony")))
  dims_use <- seq_len(n_dims)

  obj_diag <- RunUMAP(obj_diag, reduction = "pca", dims = dims_use,
                      reduction.name = "umap_before_harmony",
                      reduction.key = "preHUMAP_", seed.use = 123,
                      verbose = FALSE)
  obj_diag <- RunUMAP(obj_diag, reduction = "harmony", dims = dims_use,
                      reduction.name = "umap_after_harmony",
                      reduction.key = "postHUMAP_", seed.use = 123,
                      verbose = FALSE)

  make_embedding_df <- function(object, reduction_name, stage) {
    emb <- Embeddings(object, reduction_name)
    colnames(emb)[1:2] <- c("UMAP_1", "UMAP_2")
    coords <- as.data.frame(emb[, 1:2, drop = FALSE]) %>%
      rownames_to_column("cell_id")
    md <- object[[]] %>% rownames_to_column("cell_id")
    left_join(coords, md, by = "cell_id") %>% mutate(integration_stage = stage)
  }

  emb_df <- bind_rows(
    make_embedding_df(obj_diag, "umap_before_harmony", "Before Harmony"),
    make_embedding_df(obj_diag, "umap_after_harmony", "After Harmony")
  )

  diagnostic_cols <- intersect(
    c(dataset_col, sample_col, group_col, major_col),
    colnames(emb_df)
  )
  diagnostic_cols <- unique(diagnostic_cols)

  for (column_name in diagnostic_cols) {
    p <- ggplot(emb_df,
                aes(x = UMAP_1, y = UMAP_2, color = .data[[column_name]])) +
      geom_point(size = 0.15, alpha = 0.7) +
      facet_wrap(~integration_stage, nrow = 1) +
      coord_equal() +
      labs(title = paste("Harmony diagnostic colored by", column_name),
           color = column_name, x = "UMAP 1", y = "UMAP 2") +
      theme_classic(base_size = 10) +
      theme(legend.position = "right", strip.background = element_rect(fill = "grey95"))
    save_plot(p, paste0("04_Harmony_before_after_by_", column_name, ".pdf"),
              width = 12, height = 5.5)
  }

  write.csv(emb_df, file.path(output_dir, "05_Harmony_diagnostic_coordinates.csv"),
            row.names = FALSE)
} else {
  message("Harmony before/after plot skipped. obj_post must contain both reductions ",
          "named 'pca' and 'harmony'. Available: ", paste(reductions_present, collapse = ", "))
}

# ---------------------------
# 4. Donor contributions to major cell types and PT subclusters
# ---------------------------
make_composition_data <- function(object, category, object_name) {
  md <- get_md(object, object_name)
  if (category == "major") {
    if (!major_col %in% colnames(md)) stop("Major annotation column not found: ", major_col)
    md$cell_group <- as.character(md[[major_col]])
  } else {
    if (!is.null(pt_subtype_col) && pt_subtype_col %in% colnames(md)) {
      md$cell_group <- as.character(md[[pt_subtype_col]])
    } else {
      md$cell_group <- as.character(Idents(object)[md$cell_id])
    }
  }

  sample_info <- md %>%
    group_by(dataset_id, sample_id, condition) %>%
    summarise(total_in_object = n(), .groups = "drop")
  counts <- md %>%
    count(dataset_id, sample_id, condition, cell_group, name = "n_cells")
  groups <- sort(unique(md$cell_group))

  crossing(sample_info, cell_group = groups) %>%
    left_join(counts, by = c("dataset_id", "sample_id", "condition", "cell_group")) %>%
    mutate(n_cells = replace_na(n_cells, 0L),
           proportion = n_cells / total_in_object,
           cell_group = factor(cell_group, levels = groups))
}

major_comp <- make_composition_data(obj_post, "major", "da")
write.csv(major_comp, file.path(output_dir, "06_major_celltype_by_donor.csv"), row.names = FALSE)

p_major <- ggplot(major_comp,
                  aes(x = sample_id, y = proportion, fill = cell_group)) +
  geom_col(width = 0.9, color = "white", linewidth = 0.1) +
  facet_grid(. ~ dataset_id, scales = "free_x", space = "free_x") +
  scale_y_continuous(labels = label_percent()) +
  scale_fill_manual(values = hue_pal()(nlevels(major_comp$cell_group))) +
  labs(x = "Donor / sample", y = "Proportion of all retained cells", fill = "Cell type",
       title = "Major cell-type contribution by donor") +
  theme_classic(base_size = 10) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = "right")
save_plot(p_major, "07_major_celltype_donor_composition.pdf", width = 14, height = 7)

if (!is.null(pt_obj)) {
  pt_comp <- make_composition_data(pt_obj, "PT", "vam")
  write.csv(pt_comp, file.path(output_dir, "08_PT_subcluster_by_donor.csv"), row.names = FALSE)

  p_pt_comp <- ggplot(pt_comp,
                      aes(x = sample_id, y = proportion, fill = cell_group)) +
    geom_col(width = 0.9, color = "white", linewidth = 0.1) +
    facet_grid(. ~ dataset_id, scales = "free_x", space = "free_x") +
    scale_y_continuous(labels = label_percent()) +
    scale_fill_manual(values = hue_pal()(nlevels(pt_comp$cell_group))) +
    labs(x = "Donor / sample", y = "Proportion among PT cells", fill = "PT subcluster",
         title = "PT-subcluster contribution by donor") +
    theme_classic(base_size = 10) +
    theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
          legend.position = "right")
  save_plot(p_pt_comp, "09_PT_subcluster_donor_composition.pdf", width = 14, height = 7)

  # Sample-level proportions; donor is the unit of analysis.
  pt_prop <- pt_comp %>%
    filter(condition == control_label | condition %in% disease_labels) %>%
    mutate(condition = if_else(condition == control_label, "Control", "Disease"),
           condition = factor(condition, levels = c("Control", "Disease")))

  test_one_subtype <- function(df) {
    x <- df$proportion[df$condition == "Disease"]
    y <- df$proportion[df$condition == "Control"]
    if (length(x) < 2 || length(y) < 2) {
      return(tibble(n_disease = length(x), n_control = length(y),
                    HL_difference = NA_real_, CI_low = NA_real_, CI_high = NA_real_,
                    p_value = NA_real_))
    }
    wt <- suppressWarnings(wilcox.test(x, y, exact = FALSE, conf.int = TRUE))
    ci <- if (!is.null(wt$conf.int)) as.numeric(wt$conf.int) else c(NA_real_, NA_real_)
    tibble(n_disease = length(x), n_control = length(y),
           HL_difference = unname(wt$estimate), CI_low = ci[1], CI_high = ci[2],
           p_value = wt$p.value)
  }

  pt_tests <- pt_prop %>%
    group_by(dataset_id, cell_group) %>%
    group_modify(~test_one_subtype(.x)) %>%
    ungroup() %>%
    group_by(dataset_id) %>%
    mutate(p_adj_BH = p.adjust(p_value, method = "BH")) %>%
    ungroup()
  write.csv(pt_tests, file.path(output_dir, "10_PT_subcluster_donor_level_tests.csv"),
            row.names = FALSE)

  ann <- pt_prop %>%
    group_by(dataset_id, cell_group) %>%
    summarise(y_pos = max(proportion, na.rm = TRUE), .groups = "drop") %>%
    left_join(pt_tests, by = c("dataset_id", "cell_group")) %>%
    mutate(y_pos = if_else(y_pos > 0, y_pos * 1.18, 0.05),
           label = if_else(is.na(p_adj_BH), "not tested",
                           paste0("BH FDR = ", format.pval(p_adj_BH, digits = 2, eps = 0.001))))

  p_pt_props <- ggplot(pt_prop,
                       aes(x = condition, y = proportion, color = condition, fill = condition)) +
    geom_boxplot(width = 0.58, alpha = 0.25, outlier.shape = NA, linewidth = 0.35) +
    geom_point(position = position_jitter(width = 0.08, height = 0), size = 1.8, alpha = 0.85) +
    geom_text(data = ann, aes(x = 1.5, y = y_pos, label = label),
              inherit.aes = FALSE, size = 2.7, vjust = 0) +
    facet_grid(dataset_id ~ cell_group, scales = "free_y") +
    scale_y_continuous(labels = label_percent(), expand = expansion(mult = c(0.04, 0.28))) +
    scale_color_manual(values = c(Control = "#3C9D91", Disease = "#C95D78")) +
    scale_fill_manual(values = c(Control = "#3C9D91", Disease = "#C95D78")) +
    labs(x = NULL, y = "Proportion among PT cells", color = NULL, fill = NULL,
         title = "PT-subcluster proportions by donor",
         subtitle = "Each point represents one donor; tests are performed separately by dataset") +
    theme_classic(base_size = 9) +
    theme(legend.position = "top", strip.text.x = element_text(size = 8),
          strip.text.y = element_text(size = 8))
  save_plot(p_pt_props, "11_PT_subcluster_donor_level_proportions.pdf", width = 15, height = 7)
}

message("Plots and tables saved to: ", normalizePath(output_dir, winslash = "/", mustWork = FALSE))

# Interpretation note:
# The Wilcoxon tests above use donor-level proportions, not individual cells.
# With only three donors per group in each dataset, inferential power is limited;
# show donor points and interpret P values cautiously. Do not pool datasets for
# a single test unless the analysis explicitly models dataset/platform effects.
