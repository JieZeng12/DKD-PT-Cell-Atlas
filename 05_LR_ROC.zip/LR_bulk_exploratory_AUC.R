# Exploratory bulk expression plots and ROC analysis for CellChat-prioritized
# ligand/receptor genes. These scores are NOT direct measurements of cell-cell
# communication. They are fixed, transparent expression signatures.
#
# Inputs are the normalized gene-symbol matrices and metadata tables already
# prepared under Result/Figure5/New. Main endpoint: DKD (Early_DN + Advanced_DN
# in GSE142025) versus Control. GSE30529 is analyzed separately.

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(tibble)
  library(pROC)
})

input_dir <- "I:/DKD/DKD-SingleCell/Result/Figure5/New"
out_dir <- "I:/DKD/DKD-SingleCell/Result/Figure6/LR_bulk_AUC"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

# Prespecified candidate pairs based on the single-cell CellChat analysis.
lr_pairs <- list(
  "APP–CD74" = c("APP", "CD74"),
  "SPP1–CD44" = c("SPP1", "CD44"),
  "MIF–CD74" = c("MIF", "CD74"),
  "MIF–CD44" = c("MIF", "CD44")
)
features <- c(names(lr_pairs), "Combined signature")
# APP-CD74 and SPP1-CD44 are the prespecified common core pairs used to form
# the same combined score in both cohorts. MIF-containing pairs are evaluated
# only in cohorts where MIF is actually present in the expression matrix.
core_pairs <- c("APP–CD74", "SPP1–CD44")
feature_cols <- c(
  "APP–CD74" = "#3C78A8",
  "SPP1–CD44" = "#E07A3F",
  "MIF–CD74" = "#6A9F58",
  "MIF–CD44" = "#8C6BB1",
  "Combined signature" = "#333333"
)
group_cols <- c(Control = "#D97757", DKD = "#4197A5")

read_cohort <- function(expression_file, metadata_file, cohort_name) {
  expr <- read_tsv(file.path(input_dir, expression_file),
                   show_col_types = FALSE, name_repair = "minimal")
  meta <- read_tsv(file.path(input_dir, metadata_file),
                   show_col_types = FALSE)
  if (!"gene_symbol" %in% names(expr)) {
    stop("No gene_symbol column in ", expression_file)
  }
  if (!all(c("sample_id", "group") %in% names(meta))) {
    stop("Metadata must contain sample_id and group: ", metadata_file)
  }

  # Map cohort labels to the binary endpoint without using sample expression.
  meta <- meta %>% mutate(
    Group = case_when(
      tolower(group) %in% c("control", "normal", "healthy") ~ "Control",
      grepl("dkd|diabet|dn", tolower(group)) ~ "DKD",
      TRUE ~ NA_character_
    )
  )
  if (anyNA(meta$Group)) {
    stop("Unmapped group label(s) in ", cohort_name, ": ",
         paste(unique(meta$group[is.na(meta$Group)]), collapse = ", "))
  }

  sample_ids <- intersect(meta$sample_id, names(expr))
  if (length(sample_ids) != nrow(meta)) {
    missing <- setdiff(meta$sample_id, sample_ids)
    stop("Expression/metadata sample mismatch for ", cohort_name,
         ". Missing expression columns: ", paste(missing, collapse = ", "))
  }

  # Collapse duplicated gene symbols by the mean of their normalized values.
  expr2 <- expr %>%
    select(gene_symbol, all_of(sample_ids)) %>%
    filter(!is.na(gene_symbol), gene_symbol != "") %>%
    group_by(gene_symbol) %>%
    summarise(across(all_of(sample_ids), ~mean(as.numeric(.x), na.rm = TRUE)),
              .groups = "drop")

  gene_mat <- as.matrix(expr2[, sample_ids, drop = FALSE])
  rownames(gene_mat) <- expr2$gene_symbol
  sample_mat <- t(gene_mat)
  meta <- as.data.frame(meta[match(rownames(sample_mat), meta$sample_id), , drop = FALSE])
  rownames(meta) <- meta$sample_id

  available_pairs <- names(Filter(function(pair) all(pair %in% colnames(sample_mat)), lr_pairs))
  if (!all(core_pairs %in% available_pairs)) {
    stop("Core candidate gene pair(s) are unavailable in ", cohort_name,
         ". Required core pairs: ", paste(core_pairs, collapse = ", "))
  }
  unavailable_pairs <- setdiff(names(lr_pairs), available_pairs)
  if (length(unavailable_pairs)) {
    message(cohort_name, " lacks genes for: ", paste(unavailable_pairs, collapse = ", "),
            "; these pair scores will be omitted, not imputed.")
  }

  # Standardize each gene within cohort; this handles scale differences for
  # exploratory within-cohort score/AUC plots, but is not a locked clinical model.
  used_pairs <- lr_pairs[available_pairs]
  z <- scale(sample_mat[, unique(unlist(used_pairs)), drop = FALSE])
  score_mat <- sapply(used_pairs, function(pair) {
    rowMeans(z[, pair, drop = FALSE], na.rm = TRUE)
  })
  score_mat <- as.matrix(score_mat)
  colnames(score_mat) <- available_pairs
  score_mat <- cbind(score_mat,
                     `Combined signature` = rowMeans(score_mat[, core_pairs, drop = FALSE], na.rm = TRUE))

  out <- data.frame(
    cohort = cohort_name,
    sample_id = meta$sample_id,
    Group = factor(meta$Group, levels = c("Control", "DKD")),
    score_mat,
    check.names = FALSE
  )
  out
}

cohorts <- bind_rows(
  read_cohort("GSE142025_gene_symbol_expression.tsv",
              "GSE142025_sample_metadata.tsv", "GSE142025"),
  read_cohort("GSE30529_log2RMA_gene_symbol.tsv",
              "GSE30529_sample_metadata.tsv", "GSE30529")
)

# Print group counts to make endpoint definition explicit.
group_counts <- cohorts %>% count(cohort, Group, name = "n")
print(group_counts)
write_csv(group_counts, file.path(out_dir, "LR_bulk_group_sample_counts.csv"))

score_long <- cohorts %>%
  pivot_longer(cols = all_of(features), names_to = "Feature", values_to = "Score") %>%
  filter(!is.na(Score)) %>%
  mutate(Feature = factor(Feature, levels = features))

missing_scores <- tidyr::expand_grid(
  cohort = unique(cohorts$cohort),
  Feature = factor(features, levels = features)
) %>%
  anti_join(score_long %>% distinct(cohort, Feature), by = c("cohort", "Feature"))

# Rank-sum comparisons are exploratory and corrected within each cohort.
score_stats <- score_long %>%
  group_by(cohort, Feature) %>%
  group_modify(~ {
    dd <- .x
    p <- tryCatch(wilcox.test(Score ~ Group, data = dd, exact = FALSE)$p.value,
                  error = function(e) NA_real_)
    tibble(
      n_control = sum(dd$Group == "Control"),
      n_DKD = sum(dd$Group == "DKD"),
      median_control = median(dd$Score[dd$Group == "Control"], na.rm = TRUE),
      median_DKD = median(dd$Score[dd$Group == "DKD"], na.rm = TRUE),
      median_difference_DKD_minus_control = median_DKD - median_control,
      p_value = p
    )
  }) %>%
  ungroup() %>%
  group_by(cohort) %>%
  mutate(p_adjust_BH = p.adjust(p_value, method = "BH")) %>%
  ungroup() %>%
  mutate(label = paste0("FDR = ", format.pval(p_adjust_BH, digits = 2, eps = 0.001)))

ann_y <- score_long %>%
  group_by(cohort, Feature) %>%
  summarise(y = max(Score, na.rm = TRUE) + 0.25, .groups = "drop")
score_stats <- left_join(score_stats, ann_y, by = c("cohort", "Feature"))
write_csv(score_stats, file.path(out_dir, "LR_pair_score_group_statistics.csv"))

p_scores <- ggplot(score_long, aes(x = Group, y = Score, color = Group, fill = Group)) +
  geom_boxplot(width = 0.56, outlier.shape = NA, alpha = 0.18, linewidth = 0.65) +
  geom_point(position = position_jitter(width = 0.10, height = 0, seed = 2026),
             size = 1.8, alpha = 0.75) +
  geom_text(data = missing_scores,
            aes(x = 1.5, y = 0, label = "Unavailable\n(gene not measured)"),
            inherit.aes = FALSE, size = 2.8, color = "grey45") +
  geom_text(data = score_stats,
            aes(x = 1.5, y = y, label = label),
            inherit.aes = FALSE, size = 3.0, color = "#343A40") +
  facet_grid(cohort ~ Feature, scales = "free_y") +
  scale_color_manual(values = group_cols) +
  scale_fill_manual(values = group_cols) +
  labs(title = "Bulk expression scores for candidate ligand–receptor pairs",
       subtitle = "Pair scores are the mean of within-cohort gene-wise z-scores; exploratory comparisons",
       x = NULL, y = "Mean standardized expression score",
       color = NULL, fill = NULL,
       caption = "Bulk scores do not establish cell of origin or physical ligand–receptor communication.") +
  theme_classic(base_size = 12) +
  theme(plot.title = element_text(face = "bold", size = 16, hjust = 0.5),
        plot.subtitle = element_text(size = 10, hjust = 0.5, color = "grey35"),
        strip.background = element_rect(fill = "#EEF2F4", color = NA),
        strip.text = element_text(face = "bold", size = 9),
        axis.text.x = element_text(color = "black", size = 9),
        axis.text.y = element_text(color = "black", size = 9),
        axis.title.y = element_text(face = "bold"),
        panel.spacing = grid::unit(0.8, "lines"),
        panel.grid.major.y = element_line(color = "#E8ECEF", linewidth = 0.35),
        panel.grid.minor = element_blank(),
        legend.position = "top",
        plot.caption = element_text(hjust = 0, size = 8, color = "grey35"))

ggsave(file.path(out_dir, "LR_pair_scores_by_group.pdf"), p_scores,
       width = 15, height = 7, device = grDevices::cairo_pdf)
ggsave(file.path(out_dir, "LR_pair_scores_by_group.png"), p_scores,
       width = 15, height = 7, dpi = 320, bg = "white")

# Exploratory ROC curves for each fixed pair score and their prespecified mean.
# These are not estimates from a fitted/externally locked multivariable model.
roc_rows <- list()
roc_summaries <- list()
for (cohort_name in unique(cohorts$cohort)) {
  dd <- cohorts %>% filter(cohort == cohort_name)
  for (feat in features) {
    if (all(is.na(dd[[feat]]))) next
    roc_obj <- pROC::roc(
      response = dd$Group,
      predictor = dd[[feat]],
      levels = c("Control", "DKD"),
      direction = "auto",
      quiet = TRUE
    )
    ci <- as.numeric(pROC::ci.auc(roc_obj, method = "delong"))
    auc <- as.numeric(pROC::auc(roc_obj))
    coords <- as.data.frame(pROC::coords(
      roc_obj, x = "all", ret = c("specificity", "sensitivity"),
      transpose = FALSE
    ))
    roc_rows[[paste(cohort_name, feat, sep = "_")]] <- tibble(
      cohort = cohort_name,
      Feature = feat,
      FPR = 1 - coords$specificity,
      Sensitivity = coords$sensitivity
    )
    roc_summaries[[paste(cohort_name, feat, sep = "_")]] <- tibble(
      cohort = cohort_name,
      Feature = feat,
      n_control = sum(dd$Group == "Control"),
      n_DKD = sum(dd$Group == "DKD"),
      AUC = auc,
      CI95_low = ci[1],
      CI95_high = ci[3]
    )
  }
}
roc_df <- bind_rows(roc_rows) %>% mutate(Feature = factor(Feature, levels = features))
auc_table <- bind_rows(roc_summaries) %>% mutate(Feature = factor(Feature, levels = features))
write_csv(auc_table, file.path(out_dir, "LR_pair_exploratory_AUC.csv"))

p_roc <- ggplot(roc_df, aes(x = FPR, y = Sensitivity, color = Feature)) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey65") +
  geom_path(linewidth = 0.9) +
  facet_wrap(~cohort, ncol = 1) +
  scale_color_manual(values = feature_cols) +
  coord_equal() +
  labs(title = "Exploratory ROC analysis of candidate ligand–receptor gene scores",
       x = "1 − Specificity", y = "Sensitivity", color = "Score",
       caption = "AUCs with DeLong 95% CIs are provided in LR_pair_exploratory_AUC.csv. Cohort-wise z-scoring makes these exploratory scores, not a locked clinical model.") +
  theme_classic(base_size = 13) +
  theme(plot.title = element_text(face = "bold", size = 15, hjust = 0.5),
        strip.background = element_rect(fill = "#EEF2F4", color = NA),
        strip.text = element_text(face = "bold", size = 12),
        legend.position = "bottom",
        legend.box = "vertical",
        panel.grid = element_blank(),
        plot.caption = element_text(hjust = 0, size = 8, color = "grey35"))

p_roc <- p_roc + guides(color = guide_legend(nrow = 2, byrow = TRUE))

ggsave(file.path(out_dir, "LR_pair_exploratory_ROC.pdf"), p_roc,
       width = 9.5, height = 13, device = grDevices::cairo_pdf)
ggsave(file.path(out_dir, "LR_pair_exploratory_ROC.png"), p_roc,
       width = 9.5, height = 13, dpi = 400, bg = "white")

print(p_scores)
print(p_roc)
print(auc_table)
message("Saved exploratory plots and tables to: ", normalizePath(out_dir))
