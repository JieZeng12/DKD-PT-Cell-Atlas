# Combined-signature-only ROC plot for two renal bulk cohorts.
# Combined score is the mean of gene-wise z-scores for APP, CD74, SPP1, and CD44,
# equivalent to averaging the APP-CD74 and SPP1-CD44 pair scores.
# This exploratory score is not a fitted or clinically validated model.

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(ggplot2)
  library(pROC)
})

input_dir <- "I:/DKD/DKD-SingleCell/Result/Figure5/New"
out_dir <- "I:/DKD/DKD-SingleCell/Result/Figure6/LR_bulk_AUC"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

candidate_genes <- c("APP", "CD74", "SPP1", "CD44")
signature_color <- "#167D9A"

read_combined_cohort <- function(expression_file, metadata_file, cohort_name) {
  expr <- read_tsv(file.path(input_dir, expression_file),
                   show_col_types = FALSE, name_repair = "minimal")
  meta <- read_tsv(file.path(input_dir, metadata_file), show_col_types = FALSE) %>%
    as.data.frame()

  if (!"gene_symbol" %in% names(expr)) {
    stop("Missing gene_symbol column in ", expression_file)
  }
  if (!all(c("sample_id", "group") %in% names(meta))) {
    stop("Metadata must contain sample_id and group: ", metadata_file)
  }

  meta$Group <- dplyr::case_when(
    tolower(meta$group) %in% c("control", "normal", "healthy") ~ "Control",
    grepl("dkd|diabet|dn", tolower(meta$group)) ~ "DKD",
    TRUE ~ NA_character_
  )
  if (anyNA(meta$Group)) {
    stop("Unmapped group label(s) in ", cohort_name, ": ",
         paste(unique(meta$group[is.na(meta$Group)]), collapse = ", "))
  }

  sample_ids <- intersect(as.character(meta$sample_id), names(expr))
  if (length(sample_ids) != nrow(meta)) {
    stop("Expression/metadata sample mismatch in ", cohort_name, ". Missing: ",
         paste(setdiff(meta$sample_id, sample_ids), collapse = ", "))
  }

  # Average duplicate rows for the same gene symbol, if present.
  expr2 <- expr %>%
    select(gene_symbol, all_of(sample_ids)) %>%
    filter(!is.na(gene_symbol), gene_symbol != "") %>%
    group_by(gene_symbol) %>%
    summarise(across(all_of(sample_ids), ~ mean(as.numeric(.x), na.rm = TRUE)),
              .groups = "drop")

  absent <- setdiff(candidate_genes, expr2$gene_symbol)
  if (length(absent)) {
    stop(cohort_name, " is missing combined-signature gene(s): ",
         paste(absent, collapse = ", "))
  }

  gene_mat <- as.matrix(expr2[match(candidate_genes, expr2$gene_symbol), sample_ids,
                              drop = FALSE])
  rownames(gene_mat) <- candidate_genes
  sample_mat <- t(gene_mat)

  gene_sd <- apply(sample_mat, 2, stats::sd, na.rm = TRUE)
  if (any(!is.finite(gene_sd) | gene_sd == 0)) {
    stop("A candidate gene has zero/non-finite variance in ", cohort_name, ".")
  }
  z_mat <- scale(sample_mat)
  combined_score <- rowMeans(z_mat, na.rm = FALSE)

  meta <- meta[match(rownames(sample_mat), as.character(meta$sample_id)), , drop = FALSE]
  data.frame(
    cohort = cohort_name,
    sample_id = as.character(meta$sample_id),
    Group = factor(meta$Group, levels = c("Control", "DKD")),
    Combined_score = as.numeric(combined_score),
    stringsAsFactors = FALSE
  )
}

scores <- bind_rows(
  read_combined_cohort("GSE142025_gene_symbol_expression.tsv",
                       "GSE142025_sample_metadata.tsv", "GSE142025"),
  read_combined_cohort("GSE30529_log2RMA_gene_symbol.tsv",
                       "GSE30529_sample_metadata.tsv", "GSE30529")
)

auc_rows <- list()
roc_rows <- list()
for (cohort_name in unique(scores$cohort)) {
  dat <- filter(scores, cohort == cohort_name)
  roc_obj <- pROC::roc(
    response = dat$Group,
    predictor = dat$Combined_score,
    levels = c("Control", "DKD"),
    direction = "<", # Higher score is prespecified as the DKD direction.
    quiet = TRUE
  )
  ci <- as.numeric(pROC::ci.auc(roc_obj, method = "delong"))
  auc_value <- as.numeric(pROC::auc(roc_obj))
  n_control <- sum(dat$Group == "Control")
  n_dkd <- sum(dat$Group == "DKD")
  facet_label <- sprintf("%s  (Control n = %d; DKD n = %d)",
                         cohort_name, n_control, n_dkd)
  auc_label <- sprintf("AUC = %.3f\n95%% CI: %.3f–%.3f",
                       auc_value, ci[1], ci[3])

  roc_coords <- as.data.frame(pROC::coords(
    roc_obj, x = "all", ret = c("specificity", "sensitivity"),
    transpose = FALSE
  ))
  roc_rows[[cohort_name]] <- data.frame(
    cohort = cohort_name,
    facet_label = facet_label,
    FPR = 1 - roc_coords$specificity,
    Sensitivity = roc_coords$sensitivity
  )
  auc_rows[[cohort_name]] <- data.frame(
    cohort = cohort_name,
    facet_label = facet_label,
    auc_label = auc_label,
    n_Control = n_control,
    n_DKD = n_dkd,
    AUC = auc_value,
    CI95_low = ci[1],
    CI95_high = ci[3]
  )
}

roc_data <- bind_rows(roc_rows) %>%
  arrange(cohort, FPR, Sensitivity)
auc_table <- bind_rows(auc_rows)
facet_levels <- auc_table %>%
  arrange(match(cohort, c("GSE142025", "GSE30529"))) %>%
  pull(facet_label)
roc_data$facet_label <- factor(roc_data$facet_label, levels = facet_levels)
auc_table$facet_label <- factor(auc_table$facet_label, levels = facet_levels)

p_combined <- ggplot(roc_data,
                     aes(x = FPR, y = Sensitivity, group = cohort)) +
  geom_abline(slope = 1, intercept = 0, color = "#AAB2B8",
              linewidth = 0.65, linetype = "dotted") +
  geom_step(direction = "hv", color = signature_color, linewidth = 1.2) +
  geom_label(
    data = auc_table,
    aes(x = 0.97, y = 0.06, label = auc_label),
    inherit.aes = FALSE, hjust = 1, vjust = 0,
    size = 3.3, lineheight = 1.05,
    color = "#263238", fill = "white", label.size = 0.25
  ) +
  facet_wrap(~facet_label, ncol = 1) +
  scale_x_continuous(breaks = seq(0, 1, by = 0.2),
                     limits = c(0, 1), expand = expansion(mult = 0.015)) +
  scale_y_continuous(breaks = seq(0, 1, by = 0.2),
                     limits = c(0, 1), expand = expansion(mult = 0.015)) +
  coord_equal() +
  labs(
    title = "ROC analysis of the combined ligand–receptor signature",
    subtitle = "The two renal bulk cohorts are shown in vertically stacked panels",
    x = "1 − Specificity",
    y = "Sensitivity",
    caption = paste(
      "Combined score = mean of within-cohort gene-wise z-scores for APP, CD74, SPP1, and CD44.",
      "AUC with DeLong 95% CI is shown in each panel. This exploratory score is not a validated diagnostic model.",
      sep = "\n"
    )
  ) +
  theme_classic(base_size = 12.5) +
  theme(
    plot.title = element_text(face = "bold", size = 16, hjust = 0.5,
                              color = "#202A33"),
    plot.subtitle = element_text(size = 10.5, hjust = 0.5, color = "#56616A"),
    axis.title = element_text(face = "bold", color = "#263238"),
    axis.text = element_text(color = "#263238"),
    axis.line = element_line(color = "#45525C", linewidth = 0.55),
    axis.ticks = element_line(color = "#45525C", linewidth = 0.45),
    legend.position = "none",
    strip.background = element_rect(fill = "#EEF2F4", color = NA),
    strip.text = element_text(face = "bold", size = 10.5, color = "#263238"),
    panel.spacing = grid::unit(1.0, "lines"),
    plot.caption = element_text(size = 8.5, color = "#56616A", hjust = 0),
    plot.margin = margin(12, 18, 10, 12)
  )

write_csv(scores, file.path(out_dir, "LR_combined_signature_scores.csv"))
write_csv(auc_table, file.path(out_dir, "LR_combined_signature_AUC.csv"))
ggsave(file.path(out_dir, "LR_combined_signature_ROC.pdf"), p_combined,
       width = 8.5, height = 13, device = "pdf")
ggsave(file.path(out_dir, "LR_combined_signature_ROC.png"), p_combined,
       width = 8.5, height = 13, dpi = 400, bg = "white")

print(p_combined)
print(auc_table)
message("Combined-signature-only ROC figure and tables saved to: ", out_dir)
