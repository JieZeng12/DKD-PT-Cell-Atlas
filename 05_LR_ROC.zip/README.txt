Module: ligand–receptor expression scores and exploratory ROC plots.
Inputs: renal bulk expression and sample metadata TSV files.
These are exploratory scores, not a validated diagnostic model.
Check the input and output paths before running.
