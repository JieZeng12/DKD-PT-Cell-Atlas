# Plot GSE30529 deconvolution results in the style of the reference figure.
# Input: GSE30529_exploratory_InstaPrism_results.csv
# Output: selected 5-state and all-state violin/box/jitter plots as PDF,
#         plus the plotted statistics table.

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
})

input_file <- "GSE30529_exploratory_InstaPrism_results.csv"
stats_file <- "GSE30529_exploratory_Wilcoxon.csv"
out_dir <- getwd()

dat <- read_csv(input_file, show_col_types = FALSE, name_repair = "minimal")
stats <- read_csv(stats_file, show_col_types = FALSE)

# In this file, `Group` contains the plotting labels Control and DKD.
# The lowercase `group` column contains cohort annotations and is not used here.
stopifnot(all(c("sample_id", "Group") %in% names(dat)))
dat <- dat %>%
  mutate(Group = factor(Group, levels = c("Control", "DKD")))

all_states <- c(
  "MMP7+ PT", "ACSM2A+ PT", "TACSTD2+ PT", "CCN2+ PT",
  "UMOD+ PT-like", "GPX3+ PT", "CFH+ PT"
)
selected_states <- c(
  "MMP7+ PT", "ACSM2A+ PT", "TACSTD2+ PT", "CCN2+ PT", "UMOD+ PT-like"
)
stopifnot(all(all_states %in% names(dat)))

palette_group <- c(Control = "#E76F51", DKD = "#55B8C9")

make_plot <- function(states, filename, plot_title = NULL) {
  plot_dat <- dat %>%
    select(sample_id, Group, all_of(states)) %>%
    pivot_longer(cols = all_of(states), names_to = "Cell_state", values_to = "Score") %>%
    mutate(Cell_state = factor(Cell_state, levels = states))

  ann <- stats %>%
    filter(Cell_type %in% states) %>%
    mutate(
      Cell_state = factor(Cell_type, levels = states),
      label = case_when(
        p_adjust_BH < 0.001 ~ "***",
        p_adjust_BH < 0.01  ~ "**",
        p_adjust_BH < 0.05  ~ "*",
        TRUE ~ ""
      )
    )
  ymax <- plot_dat %>%
    group_by(Cell_state) %>%
    summarise(y = max(Score, na.rm = TRUE) + 0.06 * max(plot_dat$Score, na.rm = TRUE),
              .groups = "drop")
  ann <- left_join(ann, ymax, by = "Cell_state")

  p <- ggplot(plot_dat, aes(x = Cell_state, y = Score, fill = Group, color = Group)) +
    geom_violin(
      position = position_dodge(width = 0.86),
      width = 1.00, trim = TRUE, alpha = 0.36, linewidth = 0.85
    ) +
    geom_boxplot(
      position = position_dodge(width = 0.86),
      width = 0.27, outlier.shape = NA, alpha = 0.88,
      linewidth = 0.70
    ) +
    geom_point(
      position = position_jitterdodge(jitter.width = 0.12, dodge.width = 0.86),
      size = 2.5, alpha = 0.70
    ) +
    geom_text(
      data = ann,
      aes(x = Cell_state, y = y, label = label),
      inherit.aes = FALSE, color = "black", size = 6.5, fontface = "bold"
    ) +
    scale_fill_manual(values = palette_group, breaks = c("Control", "DKD")) +
    scale_color_manual(values = palette_group, breaks = c("Control", "DKD")) +
    scale_y_continuous(expand = expansion(mult = c(0.04, 0.17))) +
    labs(
      title = plot_title,
      x = NULL,
      y = "Deconvolution proportion score",
      fill = NULL,
      color = NULL,
      caption = "Wilcoxon rank-sum test; asterisks indicate BH-adjusted P values"
    ) +
    theme_classic(base_size = 20) +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, color = "black", size = 17),
      axis.text.y = element_text(color = "black", size = 17),
      axis.title.y = element_text(margin = margin(r = 12), size = 20),
      legend.position = "top",
      legend.text = element_text(size = 18),
      legend.key.size = unit(1.0, "cm"),
      legend.justification = "center",
      plot.title = element_text(hjust = 0.5, face = "bold", size = 24),
      plot.caption = element_text(hjust = 0, size = 13, color = "grey30"),
      plot.margin = margin(16, 20, 16, 16)
    )

  ggsave(
    filename = file.path(out_dir, filename), plot = p,
    width = max(14, 2.1 * length(states)), height = 10,
    device = grDevices::cairo_pdf
  )
  return(p)
}

# Main figure matching the five cell states shown in the reference.
p_selected <- make_plot(
  selected_states,
  "GSE30529_selected_PT_states_violin.pdf",
  "GSE30529 deconvolution of selected PT states"
)
print(p_selected)

# Supplementary version showing all seven PT states in the result table.
p_all <- make_plot(
  all_states,
  "GSE30529_all_PT_states_violin.pdf",
  "GSE30529 deconvolution of all PT states"
)
print(p_all)

# Save the exact group sizes and BH-adjusted P values used for annotations.
write_csv(
  stats %>% filter(Cell_type %in% all_states),
  file.path(out_dir, "GSE30529_PT_state_plot_statistics.csv")
)

message("PDF figures and statistics saved in: ", normalizePath(out_dir))
