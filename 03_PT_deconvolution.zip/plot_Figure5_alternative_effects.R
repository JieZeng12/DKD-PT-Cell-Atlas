# Alternative Figure 5 visualizations for renal bulk deconvolution results
# Outputs: (1) forest plot of PT-state differences by cohort;
#          (2) forest plot of Both High vs Both Low inferred immune-fraction differences.
# These are exploratory signature-abundance estimates, not direct cell counts.

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(forcats)
  library(patchwork)
  library(scales)
})

base_dir <- "I:/DKD/DKD-SingleCell/Result/Figure5/New/InstaPrism_results"
out_dir <- "I:/DKD/DKD-SingleCell/Result/Figure5/New/Alternative_effect_figures"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("GSE142025", "GSE30529")
pt_states <- c(
  "MMP7+ PT", "ACSM2A+ PT", "TACSTD2+ PT", "CCN2+ PT",
  "UMOD+ PT-like", "GPX3+ PT", "CFH+ PT"
)
cohort_cols <- c("GSE142025" = "#D97853", "GSE30529" = "#3A9BAA")

read_csv_checked <- function(path) {
  if (!file.exists(path)) stop("Input file not found: ", path)
  read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
}

# Bootstrap percentile CI for the difference in medians (DKD - Control).
median_diff_boot <- function(control, disease, B = 3000, seed = 20261023) {
  control <- control[is.finite(control)]
  disease <- disease[is.finite(disease)]
  if (length(control) < 2 || length(disease) < 2) {
    return(c(estimate = NA_real_, low = NA_real_, high = NA_real_))
  }
  set.seed(seed)
  boot <- replicate(B, {
    stats::median(sample(disease, length(disease), replace = TRUE)) -
      stats::median(sample(control, length(control), replace = TRUE))
  })
  c(
    estimate = stats::median(disease) - stats::median(control),
    low = unname(stats::quantile(boot, 0.025, na.rm = TRUE)),
    high = unname(stats::quantile(boot, 0.975, na.rm = TRUE))
  )
}

# ---- Panel A: forest plot for PT-state signature scores ----------------------
pt_long <- lapply(cohorts, function(ds) {
  dat <- read_csv_checked(file.path(base_dir, paste0(ds, "_exploratory_InstaPrism_results.csv")))
  required <- c("sample_id", "Group", pt_states)
  missing <- setdiff(required, names(dat))
  if (length(missing)) stop(ds, " PT results are missing columns: ", paste(missing, collapse = ", "))
  dat %>%
    select(sample_id, Group, all_of(pt_states)) %>%
    pivot_longer(cols = all_of(pt_states), names_to = "PT_state", values_to = "score") %>%
    mutate(Dataset = ds, Group = as.character(Group), score = as.numeric(score))
}) %>% bind_rows() %>%
  filter(Group %in% c("Control", "DKD"), is.finite(score))

pt_stats <- pt_long %>%
  group_by(Dataset, PT_state) %>%
  group_modify(~ {
    x <- .x
    key <- .y
    cval <- x$score[x$Group == "Control"]
    dval <- x$score[x$Group == "DKD"]
    boot <- median_diff_boot(cval, dval,
                             seed = 20261023 + match(key$PT_state, pt_states) +
                               100L * match(key$Dataset, cohorts))
    p <- if (length(cval) >= 2 && length(dval) >= 2) {
      suppressWarnings(stats::wilcox.test(dval, cval, exact = FALSE)$p.value)
    } else NA_real_
    data.frame(
      n_Control = length(cval), n_DKD = length(dval),
      median_Control = stats::median(cval, na.rm = TRUE),
      median_DKD = stats::median(dval, na.rm = TRUE),
      difference = boot[["estimate"]], CI_low = boot[["low"]], CI_high = boot[["high"]],
      p_value = p
    )
  }) %>%
  ungroup() %>%
  group_by(Dataset) %>%
  mutate(q_BH = p.adjust(p_value, method = "BH")) %>%
  ungroup() %>%
  mutate(
    PT_state = factor(PT_state, levels = pt_states),
    Dataset = factor(Dataset, levels = cohorts),
    significance = case_when(
      is.na(q_BH) ~ "",
      q_BH < 0.001 ~ "***",
      q_BH < 0.01 ~ "**",
      q_BH < 0.05 ~ "*",
      TRUE ~ ""
    )
  )

pt_plot <- ggplot(pt_stats, aes(x = difference, y = Dataset, color = Dataset)) +
  geom_vline(xintercept = 0, color = "grey55", linewidth = 0.45, linetype = "dashed") +
  geom_segment(
    aes(x = CI_low, xend = CI_high, y = Dataset, yend = Dataset),
    linewidth = 0.7, na.rm = TRUE
  ) +
  geom_point(size = 2.5, na.rm = TRUE) +
  geom_text(aes(label = significance), nudge_y = 0.22, size = 3.2,
            show.legend = FALSE, na.rm = TRUE) +
  facet_wrap(~PT_state, scales = "free_x", ncol = 4) +
  scale_color_manual(values = cohort_cols, guide = "none") +
  labs(
    title = "PT-state signature scores across renal bulk cohorts",
    subtitle = "Median difference (DKD − Control); points show estimates, bars show percentile-bootstrap 95% CIs",
    x = "Difference in inferred proportion score",
    y = NULL,
    caption = "Wilcoxon rank-sum tests; BH adjustment within each cohort. * q < 0.05, ** q < 0.01, *** q < 0.001. Facets use independent x-scales."
  ) +
  theme_bw(base_size = 11) +
  theme(
    plot.title = element_text(face = "bold", size = 14),
    plot.subtitle = element_text(size = 9.5, color = "grey25"),
    strip.background = element_rect(fill = "#EEF2F4", color = NA),
    strip.text = element_text(face = "bold", color = "#263238"),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    axis.text.y = element_text(face = "bold"),
    plot.caption = element_text(size = 8, hjust = 0)
  )

# ---- Panel B: immune-fraction difference heatmap -----------------------------
immune_dir <- file.path(base_dir, "Immune_figure_CD")
immune_long <- lapply(cohorts, function(ds) {
  dat <- read_csv_checked(file.path(immune_dir, paste0(ds, "_immune_plot_data.csv")))
  required <- c("sample_id", "Group", "Cell_type", "fraction")
  missing <- setdiff(required, names(dat))
  if (length(missing)) stop(ds, " immune results are missing columns: ", paste(missing, collapse = ", "))
  dat %>%
    transmute(
      Dataset = ds, sample_id = as.character(sample_id),
      Group = as.character(Group), Cell_type = as.character(Cell_type),
      fraction = as.numeric(fraction)
    )
}) %>% bind_rows() %>%
  filter(Group %in% c("Both Low", "Both High"), is.finite(fraction))

immune_stats <- immune_long %>%
  group_by(Dataset, Cell_type) %>%
  group_modify(~ {
    x <- .x
    key <- .y
    low <- x$fraction[x$Group == "Both Low"]
    high <- x$fraction[x$Group == "Both High"]
    boot <- median_diff_boot(
      low, high,
      seed = 20262000 + match(key$Cell_type, sort(unique(immune_long$Cell_type))) +
        1000L * match(key$Dataset, cohorts)
    )
    p <- if (length(low) >= 2 && length(high) >= 2) {
      suppressWarnings(stats::wilcox.test(high, low, exact = FALSE)$p.value)
    } else NA_real_
    data.frame(
      n_low = length(low), n_high = length(high),
      median_low = stats::median(low, na.rm = TRUE),
      median_high = stats::median(high, na.rm = TRUE),
      difference_pp = 100 * boot[["estimate"]],
      CI_low_pp = 100 * boot[["low"]], CI_high_pp = 100 * boot[["high"]],
      p_value = p
    )
  }) %>%
  ungroup() %>%
  group_by(Dataset) %>%
  mutate(q_BH = p.adjust(p_value, method = "BH")) %>%
  ungroup() %>%
  group_by(Cell_type) %>%
  mutate(sort_effect = max(abs(difference_pp), na.rm = TRUE)) %>%
  ungroup() %>%
  mutate(Cell_type = forcats::fct_reorder(Cell_type, sort_effect))

immune_plot <- ggplot(immune_stats, aes(y = Cell_type, color = Dataset)) +
  geom_vline(xintercept = 0, color = "grey55", linewidth = 0.45, linetype = "dashed") +
  geom_segment(aes(x = CI_low_pp, xend = CI_high_pp, yend = Cell_type),
               linewidth = 0.65, na.rm = TRUE) +
  geom_point(aes(x = difference_pp, shape = q_BH < 0.05), size = 2.2, na.rm = TRUE) +
  scale_color_manual(values = cohort_cols, name = "Cohort") +
  scale_shape_manual(
    values = c(`FALSE` = 1, `TRUE` = 16),
    labels = c(`FALSE` = "q ≥ 0.05", `TRUE` = "q < 0.05"),
    name = "BH-adjusted test"
  ) +
  facet_wrap(~Dataset, ncol = 2) +
  labs(
    title = "Immune-signature differences between PT-signature groups",
    subtitle = "Median difference (Both High − Both Low); points show estimates and bars show percentile-bootstrap 95% CIs",
    x = "Difference in inferred immune fraction (percentage points)", y = NULL,
    caption = "Wilcoxon tests with BH adjustment across immune cell types within each cohort. Positive values indicate higher inferred fractions in Both High. GSE30529 group sizes are small; interpret estimates cautiously."
  ) +
  theme_bw(base_size = 10.5) +
  theme(
    plot.title = element_text(face = "bold", size = 14),
    plot.subtitle = element_text(size = 9.5, color = "grey25"),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    axis.text.y = element_text(size = 8.2),
    legend.position = "bottom",
    plot.caption = element_text(size = 8, hjust = 0)
  )

# Save separate high-resolution vector figures plus a combined overview.
ggsave(file.path(out_dir, "Figure5A_PT_state_effect_forest.pdf"), pt_plot,
       width = 12, height = 8.5, device = "pdf")
ggsave(file.path(out_dir, "Figure5A_PT_state_effect_forest.png"), pt_plot,
       width = 12, height = 8.5, dpi = 400, bg = "white")
ggsave(file.path(out_dir, "Figure5B_immune_difference_forest.pdf"), immune_plot,
       width = 12, height = 9, device = "pdf")
ggsave(file.path(out_dir, "Figure5B_immune_difference_forest.png"), immune_plot,
       width = 12, height = 9, dpi = 400, bg = "white")

combined <- pt_plot / immune_plot + plot_layout(heights = c(1, 1.1))
ggsave(file.path(out_dir, "Figure5_alternative_combined.pdf"), combined,
       width = 13, height = 16, device = "pdf")
ggsave(file.path(out_dir, "Figure5_alternative_combined.png"), combined,
       width = 13, height = 16, dpi = 350, bg = "white")

write.csv(pt_stats, file.path(out_dir, "PT_state_effect_statistics.csv"), row.names = FALSE)
write.csv(immune_stats, file.path(out_dir, "immune_fraction_difference_statistics.csv"), row.names = FALSE)

message("Finished. Outputs saved in: ", normalizePath(out_dir, winslash = "/", mustWork = FALSE))
