Module: GSE30529 PT-state deconvolution plots and alternative Figure 5 plots.
Inputs: deconvolution score and statistics tables named in each R script.
Check working and output paths before running.
