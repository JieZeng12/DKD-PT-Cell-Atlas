# Redesigned GSE30529 deconvolution figure
# Sample-level scores are shown as individual observations with boxplots.
# This avoids relying on violin-density estimates with modest sample sizes.

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
})

input_file <- "GSE30529_exploratory_InstaPrism_results.csv"
stats_file <- "GSE30529_exploratory_Wilcoxon.csv"
out_dir <- getwd()

dat <- read_csv(input_file, show_col_types = FALSE, name_repair = "minimal")
stats <- read_csv(stats_file, show_col_types = FALSE)

states <- c(
  "MMP7+ PT", "ACSM2A+ PT", "TACSTD2+ PT", "CCN2+ PT",
  "UMOD+ PT-like", "GPX3+ PT", "CFH+ PT"
)

stopifnot(all(c("sample_id", "Group") %in% names(dat)))
stopifnot(all(states %in% names(dat)))

dat <- dat %>%
  mutate(Group = factor(Group, levels = c("Control", "DKD")))

plot_dat <- dat %>%
  select(sample_id, Group, all_of(states)) %>%
  pivot_longer(
    cols = all_of(states),
    names_to = "Cell_state",
    values_to = "Score"
  ) %>%
  mutate(Cell_state = factor(Cell_state, levels = states))

group_n <- dat %>% count(Group) %>%
  mutate(label = paste0(Group, " n=", n)) %>%
  pull(label) %>% paste(collapse = "; ")

# Use the existing sample-level Wilcoxon results and BH-adjusted P values.
ann <- stats %>%
  filter(Cell_type %in% states) %>%
  transmute(
    Cell_state = factor(Cell_type, levels = states),
    label = paste0("BH-FDR = ", format.pval(p_adjust_BH, digits = 2, eps = 0.001))
  )

ann_y <- plot_dat %>%
  group_by(Cell_state) %>%
  summarise(
    y = max(Score, na.rm = TRUE) + max(diff(range(Score, na.rm = TRUE)) * 0.22,
                                       max(Score, na.rm = TRUE) * 0.10, 0.005),
    .groups = "drop"
  )
ann <- left_join(ann, ann_y, by = "Cell_state")

group_cols <- c(Control = "#D97757", DKD = "#4197A5")

p <- ggplot(plot_dat, aes(x = Group, y = Score, colour = Group, fill = Group)) +
  geom_boxplot(
    width = 0.52,
    outlier.shape = NA,
    alpha = 0.18,
    linewidth = 0.8,
    position = position_dodge(width = 0.68)
  ) +
  geom_point(
    position = position_jitter(width = 0.11, height = 0, seed = 2026),
    size = 2.25,
    alpha = 0.78,
    stroke = 0
  ) +
  geom_text(
    data = ann,
    aes(x = 1.5, y = y, label = label),
    inherit.aes = FALSE,
    colour = "#343A40",
    size = 3.5,
    fontface = "plain",
    vjust = 0
  ) +
  facet_wrap(~Cell_state, scales = "free_y", ncol = 4) +
  scale_colour_manual(values = group_cols) +
  scale_fill_manual(values = group_cols) +
  scale_y_continuous(expand = expansion(mult = c(0.06, 0.30))) +
  labs(
    title = "GSE30529 | Proximal-tubule state deconvolution",
    subtitle = paste("Sample-level inferred scores by group —", group_n),
    x = NULL,
    y = "Inferred proportion score",
    colour = NULL,
    fill = NULL,
    caption = "Points represent individual samples; boxplots show median and interquartile range. P values are BH-adjusted Wilcoxon rank-sum tests."
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(size = 20, face = "bold", colour = "#20262E", hjust = 0),
    plot.subtitle = element_text(size = 12, colour = "#58616B", margin = margin(b = 12)),
    plot.caption = element_text(size = 9, colour = "#626B73", hjust = 0, margin = margin(t = 12)),
    strip.text = element_text(size = 12, face = "bold", colour = "#29323A"),
    strip.background = element_rect(fill = "#EEF2F4", colour = NA),
    panel.border = element_rect(fill = NA, colour = "#D8DEE3", linewidth = 0.6),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(colour = "#E8ECEF", linewidth = 0.45),
    axis.text = element_text(colour = "#384149"),
    axis.title.y = element_text(face = "bold", margin = margin(r = 10)),
    legend.position = "top",
    legend.justification = "left",
    legend.text = element_text(size = 12),
    panel.spacing = grid::unit(1.15, "lines"),
    plot.margin = margin(12, 16, 12, 12)
  )

print(p)

ggsave(
  file.path(out_dir, "GSE30529_PT_states_redesigned.pdf"),
  plot = p, width = 14, height = 9, units = "in",
  device = grDevices::cairo_pdf
)
ggsave(
  file.path(out_dir, "GSE30529_PT_states_redesigned.png"),
  plot = p, width = 14, height = 9, units = "in", dpi = 320,
  bg = "white"
)

message("Saved redesigned PDF and PNG to: ", normalizePath(out_dir))
